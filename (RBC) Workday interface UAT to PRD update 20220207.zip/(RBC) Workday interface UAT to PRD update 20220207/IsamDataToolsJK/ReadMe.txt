﻿Isam Data Tools JK Help File

If the input argument count > 0, it will assume using command mode

Command                          Usage
========================================================================================
-help                            Show Help File
-user                            Input User Name from argument instead of command prompt
-pwd                             Input Password from argument instead of command prompt
-mode [conv|comp]                Set which application will be used
                                 [conv]=ISAM Data Convert
                                 [comp]=DDF Compare and synchronize
-nopause                         No pause after the program end
-nolog                           Do not generate log file

For ISAM Data Convert
-runtime [path]                  Specify the data folder (e.g. "C:\v11\Server\data")
-oldddf [path]                   Specify the old DDF file
-newddf [path]                   Specify the new DDF file
-force                           Force rebuild the data even DDF has no difference
-nodelempty                      Do not delete empty table when rebuild
-nobackup                        Do not backup when rebuild data
-buildonly                       Only rebuild the ledger specified by command
-incl [ledger,ledger2...]        Include these ledger when rebuild (e.g. D01,D02)
-excl [ledger,ledger2...]        Exclude these ledger when rebuild (e.g. D01,D02)

Example: IsamDataToolsJK.exe -mode conv -runtime "C:\v11\Server\data" -oldddf "C:\v11\Server\axon.ddf" -newddf "C:\v11\Server\axon.ddf" -force -nobackup -buildonly -incl COM,D01


For DDF Compare
-cmpdd [path]                    Path of the CMPDD tool (e.g. P:\cmpdd\cmpdd.exe)
-ddf1  [path]                    DDF Path 1
-ddf2  [path]                    DDF Path 2
-1to2                            Synchronize direction from DDF Path 1 to DDF Path 2
-2to1                            Synchronize direction from DDF Path 2 to DDF Path 1
-ignoresameclass                 Ignore synchronize the class exists in both side
-neweronly                       Compare the specific class's build date and version
                                 only synchronize if the source's class is newer
-forcesync [class,class2...]     Force synchronize these class even ignored by 
                                 "-ignoresameclass" or "-neweronly" command
-ignorediff [class,class2...]    Ignore the difference of these class and has higher
                                 priority than "-forcesync"

Example: IsamDataToolsJK.exe -mode comp -ddf1 C:\axon.ddf -ddf2 C:\axon2.ddf -1to2
