1. SFTP connection still pending.
2. PRD encryption key still pending.