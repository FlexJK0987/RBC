1. Added logic to StaffReportLayout will be removed issue.
2. Also commited Termination case, Add 1 day to XML effective date for termDate