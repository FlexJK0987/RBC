﻿Update Isam Data Tools JK Help File

If the input argument count > 0, it will assume using command mode

Command                          Usage
========================================================================================
-help                            Show Help File
-user                            Input User Name from argument instead of command prompt
-pwd                             Input Password from argument instead of command prompt
-nopause                         No pause after the program end
-nolog                           Do not generate log file





FxISAM refer path : V:\csharp\framework4.0\datatable.fxisam\resources\dll