Program : FxStopDC
Version : 1.0.0.0
Date    : 31-oct-2007

This is a program for determinate DC
 

commandline format, there are two method for stop DC
	
1 : stop dc by tcp/ip   

	commandline format : Start StopServer.exe  [ip] [port]

	example :  Start StopServer.exe 202.82.52.149 6001  
	
2 : stop dc by pipe
	
	commandline format : Start StopServer.exe  [PipeName]
	
	example :  Start StopServer.exe NamTest  

			
			
		
